<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US" sourcelanguage="en">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.cpp" line="71"/>
        <source>%1 (Custom Model)[*]</source>
        <oldsource>Zipcodes2 (Custom Model)[*]</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="74"/>
        <source>%1 (QStandardItemModel)[*]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="77"/>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="84"/>
        <source>Load...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="86"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="89"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="92"/>
        <source>Delete...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="95"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="98"/>
        <source>Filter or Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="100"/>
        <source>Don&apos;t Filter or Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="101"/>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="104"/>
        <source>Select by Criteria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="105"/>
        <source>Min. Zip:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="110"/>
        <source>Max. Zip:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="116"/>
        <source>County</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="120"/>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="260"/>
        <source>Unsaved changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="273"/>
        <source>%1 - Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="275"/>
        <source>%1 (*.dat)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="307"/>
        <location filename="mainwindow.cpp" line="329"/>
        <source>%1 - %2[*]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="379"/>
        <source>Delete Zipcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="380"/>
        <source>Delete Zipcode %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="260"/>
        <source>Save unsaved changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="mainwindow.cpp" line="310"/>
        <source>Loaded %n zipcode(s) from %1</source>
        <translation>
            <numerusform>Loaded one zipcode from %1</numerusform>
            <numerusform>Loaded %n zipcodes from %1</numerusform>
        </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="313"/>
        <source>Failed to load %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="313"/>
        <location filename="mainwindow.cpp" line="336"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="332"/>
        <source>Saved %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="336"/>
        <source>Failed to save %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="356"/>
        <source>(Unknown)</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="mainwindow.cpp" line="449"/>
        <source>Selected %L1 out of %Ln zipcode(s)</source>
        <oldsource>Selected %L1 out of %L2 zipcode(s)</oldsource>
        <translation type="unfinished">
            <numerusform>Selected %L1 from one zipcode</numerusform>
            <numerusform>Selected %L1 out of %Ln zipcodes</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="mainwindow.cpp" line="481"/>
        <source>Filtered %L1 out of %Ln zipcode(s)</source>
        <oldsource>Filtered %L1 out of %Ln zipcodes</oldsource>
        <translation type="unfinished">
            <numerusform>Filtered %L1 from one zipcode</numerusform>
            <numerusform>Filtered %L1 out of %Ln zipcodes</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../aqp/aqp.cpp" line="147"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aqp/aqp.cpp" line="148"/>
        <source>Do &amp;Not Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aqp/aqp.hpp" line="59"/>
        <source>&amp;Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aqp/aqp.hpp" line="60"/>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StandardTableModel</name>
    <message>
        <location filename="standardtablemodel.cpp" line="36"/>
        <source>Zipcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="standardtablemodel.cpp" line="37"/>
        <source>Post Office</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="standardtablemodel.cpp" line="37"/>
        <source>County</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="standardtablemodel.cpp" line="37"/>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="standardtablemodel.cpp" line="53"/>
        <location filename="standardtablemodel.cpp" line="99"/>
        <source>no filename specified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="standardtablemodel.cpp" line="62"/>
        <source>unrecognized file type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="standardtablemodel.cpp" line="66"/>
        <source>file format version is too new</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>_Alphabet</name>
    <message>
        <location filename="../aqp/alt_key.hpp" line="44"/>
        <source>0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ</source>
        <comment>Accelerator Keys</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.cpp" line="23"/>
        <source>Zipcodes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
