#!/usr/bin/env bash
tar xvf ch08-small-quotes.tgz
